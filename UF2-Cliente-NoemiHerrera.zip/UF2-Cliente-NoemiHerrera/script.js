/*Creo una función donde declaro el objeto que nos guardara el ID, los pilotos y el tiempo de la vuelta.*/
function Kart(numero, piloto, tiempo) 
{
    this.numero = numero;
    this.piloto = piloto;
    this.tiempo = tiempo;
    this.push = function(karts) 
    {
        karts.push(this);
    }
    this.printInfo = function() {
        console.log("numero: ", this.numero);
        console.log("piloto: ", this.piloto);
        console.log("tiempo: ", this.tiempo);
    }
}

/* Creo una matriz. */
const karts = [];

/* Añado 5 datos de jugadores */
let kart = new Kart(23, "Daniel", "03:47:1486");
kart.push(karts);
kart = new Kart(41, "Elena", "03:54:2733");
karts.push(kart);
kart = new Kart(14, "Sara", "03:55:2345");
kart.push(karts);
kart = new Kart(08, "José", "04:12:8174");
karts.push(kart)
kart = new Kart(10, "Lucas", "04:18:3542");
kart.push(karts);


/* Imprimo los datos introducidos por la consola */
karts.forEach(kart => kart.printInfo());

/* Añado la función que nos llenará las filas exigidas de la tabla*/
function plantillaFila(kart) {
    return `
      <tr class="data-row">
        <td class="data-kart data-ele"> ${kart.numero} </td>
        <td class="data-piloto data-ele"> ${kart.piloto} </td>
        <td class="data-tiempo data-ele"> ${kart.tiempo} </td>
      </tr>
    `;
}

/* Realizo la ejecución del script con una función */
document.addEventListener("DOMContentLoaded", () => 
{
  document.getElementById("tabla").innerHTML = `
    <table>
      <tr id="encabezados">
        <th class="titulo">KART</th>
        <th class="titulo">PILOTO</th>
        <th class="titulo">TIEMPO</th>
      </tr>
    ${karts.map(plantillaFila, kart).join('')}
    </table>
  `;
});